<!DOCTYPE html>
<html>

    <head>
        <title>Desafio GIGANINJA</title>
        <!--Import Google Icon Font-->
        <link href="http://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
        <!--Import materialize.css-->
        <link rel="stylesheet" href="materialize/css/materialize.min.css" />

        <!--Let browser know website is optimized for mobile-->
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <meta charset="utf-8">

        <style>
            .box-img{
                width: 40%;
                float: left;
                margin-right: 10px;
            }

            .img-divulgacao{
                width: 100%;
            }

            .evento{
                width: 100%;
                display: table;
                border-bottom: 1px solid #CCC;
                padding-bottom: 20px;        
            }

        </style>

    </head>
    <body class="card-panel grey lighten-2">
        
        <header class="row topo">            
            <nav class="nav-wrapper">
                <div class="container">                        
                    <a href="#" class="brand-logo left">Desafio Giga Ninja</a>

                    <div class="right">
                        <a href="#">Menu</a> | 
                        <a href="#">Menu</a> | 
                        <a href="#">Menu</a> | 
                        <a href="#">Menu</a> | 
                        <a href="#">Menu</a>
                    </div>

                </div>
            </nav>            
        </header>

        <div class="container">

            <div class="row">

                <div class="col s12 m3">

                    
                </div>

                <div class="col s12 m8 push-m1">
                    <h4 style="margin: 0;">Produtos</h4>

                    <hr>
                    <br>
                    
                    <?php 
                            include_once 'adm/conexao.php';
                    
                            $id = $_POST["id"];
                            
                            $sql = "select * from produto where id = '".$id."'";                            
                            $result = mysqli_query($con, $sql);                            
                            $row = mysqli_fetch_array($result);
                                
                                $data = explode("-", $row["dtevento"]); //[aaaa][mm][dd]
                                $data = array_reverse($data); //[dd][mm][aaaa]
                                $data = implode("/", $data); //dd/mm/aaaa
                    
                            $sql2 = "SELECT * from item where id_produto = '".$id."'";
                            $result2 = mysqli_query($con, $sql2);  
                            $row2 = mysqli_fetch_array($result2);
                    ?>                    
                                               
                    <div class="evento">
                        <h5><?php echo $row["titulo"];?></h5>

                        <div class="box-img">
                            <img src="img/<?php echo $row["foto"];?>" alt="" class="img-divulgacao materialboxed">
                        </div>
                        
                        
                        <?php echo $row["descricao"];?> 
                        <br>
                        <h4>Preço</h4>
                        <h5>R$ <?php echo $row2["valor"];?>,00 </h5> 
                        
                    <form action="comprar.php" method="post">
                    
                    <input type="number" id="sCepDestino" name="sCepDestino" maxlength="8" required placeholder="Digite o CEP">
                    <input type="hidden" id="valor" name="valor" value="<?php echo $row2["valor"];?>">
                    <input type="hidden" id="id" name="id" value="<?php echo $row["id"];?>">
                                                    
                    <br>
                    <input type="submit" value="Comprar" class="btn">

                    </form>
                                                               
                    </div>
                                                            
                    <a href="index.php" class="btn red lighten-2">Inicio</a>
                     
                  </div>
                                        
            </div>            
            

        </div>

         <footer class="page-footer">
             <div class="footer-copyright">
                 <div class="container">
                     © 2019 Copyright 
                     <a class="grey-text text-lighten-4 right" href="http://cotiinformatica.com.br" target="_blank">Guilherme Pimenta</a>
                 </div>
             </div>
         </footer>

        <script type="text/javascript" src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
        <script type="text/javascript" src="materialize/js/materialize.min.js"></script>


    </body>
</html>