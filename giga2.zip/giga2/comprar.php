<?php

include_once 'adm/conexao.php';

//inicio frete correios 

 $data['nCdEmpresa'] = '';
 $data['sDsSenha'] = '';
 $data['sCepOrigem'] = '24030211';
 $data['sCepDestino'] = $_POST['sCepDestino'];
 $data['nVlPeso'] = '1';
 $data['nCdFormato'] = '1';
 $data['nVlComprimento'] = '16';
 $data['nVlAltura'] = '5';
 $data['nVlLargura'] = '15';
 $data['nVlDiametro'] = '0';
 $data['sCdMaoPropria'] = 's';
 $data['nVlValorDeclarado'] = '200';
 $data['sCdAvisoRecebimento'] = 'n';
 $data['StrRetorno'] = 'xml';
 //$data['nCdServico'] = '40010';
 $data['nCdServico'] = '40010';
 $data = http_build_query($data);

 $url = 'http://ws.correios.com.br/calculador/CalcPrecoPrazo.aspx';

 $curl = curl_init($url . '?' . $data);
 curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);

 $result = curl_exec($curl);
 $result = simplexml_load_string($result);
 foreach($result -> cServico as $row) {
 //Os dados de cada serviço estará aqui
 if($row -> Erro == 0) {
   //  echo $row -> Codigo . '<br>';
   $row -> Valor;
   //  echo $row -> PrazoEntrega . '<br>';
   //  echo $row -> ValorMaoPropria . '<br>';
   //  echo $row -> ValorAvisoRecebimento . '<br>';
   //  echo $row -> ValorValorDeclarado . '<br>';
   //  echo $row -> EntregaDomiciliar . '<br>';
   //  echo $row -> EntregaSabado;
 } else {
     echo $row -> MsgErro;
 }
 
 } //fim do foreach

//fim frete correios

//inicio captura de dados formulario

$valor = $_POST['valor'];//recebe o valor do valor inserido no item
$id_produto = $_POST['id'];//recebe o id do produto

$valorfrete = $row -> Valor;

//echo $valorfrete . '<br>';

$valorfrete = str_replace(".", ",", $valorfrete);
//$valorfrete = str_replace(",", ".", $valorfrete); 

$total = $valor;

$datahora = date("YmdHis");

$notafiscal = rand(10000,99999);

//echo $datahora .'<br>';

//echo $notafiscal .'<br>';

$sql2 = "select id_item from item where id_produto = ".$id_produto;

$result2 = mysqli_query($con,$sql2);
        
$row2 = mysqli_fetch_array($result2);

$id_item = $row2['id_item'];

//echo $id_produto . '<br>';

//echo $id_item . '<br>';

$desconto = 0;

$total = str_replace(".", ",", $total);
$total = str_replace(",", ".", $total);

if($total >= 100){
$desconto = 0;
$desconto = $total*0.10;
$desconto = str_replace(".", "", $desconto);
$desconto = str_replace(",", ".", $desconto);
$total = $total - $desconto;
}

$valortotal = $total + $valorfrete;

//$valortotal = str_replace(".", "", $valortotal);
//$valortotal = str_replace(",", ".", $valortotal);         
//echo $desconto . '<br>';
//echo $valortotal . '<br>';
    
?>

<!DOCTYPE html>
<html>

    <head>
        <title>Desafio GIGANINJA</title>
        <!--Import Google Icon Font-->
        <link href="http://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
        <!--Import materialize.css-->
        <link rel="stylesheet" href="materialize/css/materialize.min.css" />

        <!--Let browser know website is optimized for mobile-->
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <meta charset="utf-8">

        <style>
            .box-img{
                width: 40%;
                float: left;
                margin-right: 10px;
            }

            .img-divulgacao{
                width: 100%;
            }

            .evento{
                width: 100%;
                display: table;
                padding-bottom: 20px;        
            }

        </style>

    </head>
    <body class="card-panel grey lighten-2">
        
        <header class="row topo">            
            <nav class="nav-wrapper">
                <div class="container">                        
                    <a href="#" class="brand-logo left">Carrinho de Compras</a>

                    <div class="right">
                        <a href="#">Menu</a> | 
                        <a href="#">Menu</a> | 
                        <a href="#">Menu</a> | 
                        <a href="#">Menu</a> | 
                        <a href="#">Menu</a>
                    </div>

                </div>
            </nav>            
        </header>

        <div class="container">

            <div class="row">
                
                <div class="col s12 m3">

                    
                </div>

                <div class="col s12 m8 push-m1">
                
                   <hr>
                    
                    <?php 
                                                        
                            $sql = "select * from produto where id = '".$id_produto."'";                            
                            $result = mysqli_query($con, $sql);                            
                            $row = mysqli_fetch_array($result);
                                
                                $data = explode("-", $row["dtevento"]); //[aaaa][mm][dd]
                                $data = array_reverse($data); //[dd][mm][aaaa]
                                $data = implode("/", $data); //dd/mm/aaaa
                    
                            $sql2 = "SELECT * from item where id_produto = '".$id_produto."'";
                            $result2 = mysqli_query($con, $sql2);  
                            $row2 = mysqli_fetch_array($result2);
                    ?>                    
                                               
                    <div class="evento">
                        <h5><?php echo $row["titulo"];?></h5>

                        <div class="box-img">
                            <img src="img/<?php echo $row["foto"];?>" alt="" class="img-divulgacao materialboxed">
                        </div>
                        <p>A sua compra é de</p>
                        <h6>R$ <?php echo $row2["valor"];?>,00 </h6> 
                        <p>Os produtos acima de R$ 100,00 terão desconto de 10%.</p>
                        <p>Seu desconto é de:</p>
                        <h6>R$ <?php echo $desconto; ?></h6>
                        <p>Valor do Frete</p>
                        <h6>R$ <?php echo $valorfrete; ?></h6>
                        <p>Valor Total</p>
                        <h6>R$ <?php echo $valortotal; ?></h6>
                        
                    <form action="adm/gravar-pedido.php" method="post">
                    
                    <input type="hidden" id="data" name="data" value="<?php echo $datahora; ?>">
                    <input type="hidden" id="nota" name="nota" value="<?php echo $notafiscal; ?>">
                    <input type="hidden" id="frete" name="frete" value="<?php echo $valorfrete; ?>">
                    <input type="hidden" id="desconto" name="desconto" value="<?php echo $desconto; ?>">
                    <input type="hidden" id="valortotal" name="valortotal" value="<?php echo $valortotal ?>">
                    <input type="hidden" id="id_produto" name="id_produto" value="<?php echo $id_produto;?>">
                    <input type="hidden" id="id_item" name="id_item" value="<?php echo $id_item;?>">
                                                    
                    <br>
                    <input type="submit" value="Comprar" class="btn">

                    </form>
                                                               
                    </div>
                                                            
                    <a href="index.php" class="btn red lighten-2">Inicio</a>
                     
                  </div>
                                        
            </div>            
      
        </div>

         <footer class="page-footer">
             <div class="footer-copyright">
                 <div class="container">
                     © 2019 Copyright 
                     <a class="grey-text text-lighten-4 right" href="http://cotiinformatica.com.br" target="_blank">Guilherme Pimenta</a>
                 </div>
             </div>
         </footer>

        <script type="text/javascript" src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
        <script type="text/javascript" src="materialize/js/materialize.min.js"></script>


    </body>
</html>

