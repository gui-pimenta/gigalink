<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        
            $nome = $_POST["nome"];
            $descricao = $_POST["descricao"];
            $cidade = $_POST["cidade"]; 
            $endereco = $_POST["endereco"];
            $bairro = $_POST["bairro"];
            $numero = $_POST["numero"];
            $telefone = $_POST["telefone"];
            $ddd = $_POST["DDD"];
            $email = $_POST["email"];
            $referencia = $_POST["referencia"];
                        
                            
            include_once 'conexao.php';

            $sql = "insert into fornecedor values(null,
            '".$nome."','".$descricao."','".$cidade."','".$endereco."','".$bairro."','".$numero."',)";
                    
             if(mysqli_query($con, $sql)){
                   
                }else{
                    $msg = "Erro ao gravar fornecedor!";
                }
        
            $id_fornecedor = "select id from fornecedor where nome = '".$nome."'";
        
            $sql3 = "insert into telefone values(null,'".$ddd."','".$telefone."','".$id_fornecedor."')";
        
               
            $sql4 = "insert into email values(null,'".$email."','".$referencia."','".$id_fornecedor."')";
        
        
             if(mysqli_query($con, $sql3)){
                    
                }else{
                    $msg = "Erro ao gravar telefone!";
                }
        
             if(mysqli_query($con, $sql4)){
                    $msg = "Gravado com sucesso!";

                }else{
                    $msg = "Erro ao gravar!";
                }
             
                     

            mysqli_close($con);

                    
        ?>
      
        <script>
            alert('<?php echo $msg;?>');
            //Redirecionar o usuário para o painel
            location.href="painel.php";
        </script>
      
    </body>
</html>