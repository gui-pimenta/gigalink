<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Atualizar Produto</title>
    </head>
    <body>
                
        <?php
        
            $id = $_POST["id"];
            $titulo = $_POST["titulo"];
            $descricao = $_POST["descricao"];
           
        $con = mysqli_connect("localhost","root","","giga2");
        
        $sql = "update produto set titulo = '".$titulo."', descricao = '".$descricao."' where id = ".$id;
        
        if(mysqli_query($con, $sql)){
            $msg = "Atualizado com sucesso!";
        }else{
            $msg = "Erro ao atualizar";
        }
        
        mysqli_close($con);
        
        ?>
        
        
        <script>
        
            alert('<?php echo $msg;?>');
            location.href="painel.php";
        
        </script>
       
        
    </body>
</html>
