<!DOCTYPE html>
<html>

<head>
    <title>Materialize</title>

    <link rel="stylesheet" href="../materialize/css/materialize.min.css" />
    <meta charset="utf-8">

    <style>

        .produto,.fornecedor,.email,.telefone,.transportadora,.item{
        
            margin: 20px 0;
            
        }
        
    </style>

</head>

<body class="card-panel grey lighten-2">
    <?php
        // put your code here
        ?>

    <header class="row topo">
        <nav class="nav-wrapper">
            <div class="container">
                <a href="#" class="brand-logo left">Painel do Sistema</a>

                <div class="right">

                </div>

            </div>
        </nav>
    </header>

    <div class="container">

        <div class="produto">
        
        <a href="cadastrar-produto.php" class="btn">Cadastrar Produto</a>
        <a href="consultar-produto.php" class="btn">Consultar Produto</a>
        
        </div>
        
        <div class="item">
        
        <a href="cadastrar-item.php" class="btn">Cadastrar item</a>
                
        </div>
        
        <div class="fornecedor">
        
        <a href="cadastrar-fornecedor.php" class="btn">Cadastrar Fornecedor</a>
        <a href="consultar-fornecedor.php" class="btn">Consultar Fornecedor</a>
        
        </div>
        
        <div class="email">
        
        <a href="cadastrar-email.php" class="btn">Cadastrar email</a>
                
        </div>
        
        <div class="telefone">
        
        <a href="cadastrar-telefone.php" class="btn">Cadastrar telefone</a>
                
        </div>
        
        <div class="transportadora">
        
        <a href="cadastrar-transportadora.php" class="btn">Cadastrar Transportadora</a>
                
        </div>       
        
        
        <a href="../index.php" class="btn">Sair</a>

    </div>

</body>

</html>
