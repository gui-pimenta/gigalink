<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>


<?php

include_once 'conexao.php';

//inicio frete correios 

 $data['nCdEmpresa'] = '';
 $data['sDsSenha'] = '';
 $data['sCepOrigem'] = '24030211';
 $data['sCepDestino'] = $_POST['sCepDestino'];
 $data['nVlPeso'] = '1';
 $data['nCdFormato'] = '1';
 $data['nVlComprimento'] = '16';
 $data['nVlAltura'] = '5';
 $data['nVlLargura'] = '15';
 $data['nVlDiametro'] = '0';
 $data['sCdMaoPropria'] = 's';
 $data['nVlValorDeclarado'] = '200';
 $data['sCdAvisoRecebimento'] = 'n';
 $data['StrRetorno'] = 'xml';
 //$data['nCdServico'] = '40010';
 $data['nCdServico'] = '40010';
 $data = http_build_query($data);

 $url = 'http://ws.correios.com.br/calculador/CalcPrecoPrazo.aspx';

 $curl = curl_init($url . '?' . $data);
 curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);

 $result = curl_exec($curl);
 $result = simplexml_load_string($result);
 foreach($result -> cServico as $row) {
 //Os dados de cada serviço estará aqui
 if($row -> Erro == 0) {
   //  echo $row -> Codigo . '<br>';
   $row -> Valor;
   //  echo $row -> PrazoEntrega . '<br>';
   //  echo $row -> ValorMaoPropria . '<br>';
   //  echo $row -> ValorAvisoRecebimento . '<br>';
   //  echo $row -> ValorValorDeclarado . '<br>';
   //  echo $row -> EntregaDomiciliar . '<br>';
   //  echo $row -> EntregaSabado;
 } else {
     echo $row -> MsgErro;
 }
 
 } //fim do foreach

//fim frete correios

//inicio captura de dados formulario

$valor = $_POST['valor'];//recebe o valor do valor inserido no item
$id_produto = $_POST['id'];//recebe o id do produto

$valorfrete = $row -> Valor;

//echo $frete . '<br>';

$total = $valorfrete + $valor;



$datahora = date("d/m/Y-H:i:s");

$notafiscal = rand(10000,99999);

//echo $data .'<br>';

//echo $notafiscal .'<br>';

$sql2 = "select id_item from item where id_produto = ".$id_produto;

$result2 = mysqli_query($con,$sql2);
        
$row2 = mysqli_fetch_array($result2);

$id_item = $row2['id_item'];

//echo $id_produto . '<br>';

//echo $id_item . '<br>';

$desconto = 0;

if($total > 100){
$desconto = $total*0.10;
$total = $total - $desconto;
}

$valortotal = $total;

        
//echo $desc . '<br>';
//echo $total . '<br>';
        
$sql = "insert into pedido values(null,'".$datahora."','".$notafiscal."','".$valorfrete."','".$desconto."','".$valortotal."','".$id_produto."','".$id_item."')";

if(mysqli_query($con, $sql)){
$msg = "Gravado com sucesso!";
}else{
$msg = "Erro ao gravar!";
}

mysqli_close($con);

?>

<script>
//alert('<?php echo $msg;?>');
//Redirecionar o usuário para o painel
//location.href="index.php";
</script>


</body>
</html>