<?php 
    include_once 'conexao.php';
?>

<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Consultar Produto</title>
        <link rel="stylesheet" href="../materialize/css/materialize.css">
        <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
        <link rel="stylesheet" href="style.css">
        
                
        <script>
            function confirmaExclusao(id){
               if(confirm('Deseja realmente excluir esse produto?')){
                   location.href="excluir-produto.php?id="+id;
               }                 
            }        
        </script>
        
    </head>
    <body>
      
      
        <div class="container">
            
            <div class="login">
            
            <h3>Consulta Produtos</h3>
            
            <form action="consultar-produto.php" method="get">
                
                <input type="text" name="titulo" placeholder="Digite o nome para pesquisar">
                <input type="submit" value="Pesquisar" class="btn">
                
                <a href="../index.php" class="btn">Sair</a>
                
            </form>
            <br>
                       
        <?php
        
            if(isset($_GET["titulo"])){
                
                $nome = $_GET["titulo"];
                
                $con = mysqli_connect("localhost","root","","giga2") or die('Erro de Conexão');
                
                $sql = "select * from produto where titulo like'".$nome."%'";
                
                $result = mysqli_query($con, $sql);
                
                if(mysqli_num_rows($result)>0){
        ?>     
        
        <table>
            
            <tr>
                <th>Título</th>
            </tr>
        
        
        <?php
                while($row = mysqli_fetch_array($result)){
        ?>
            <tr>
                <td><?php echo $row["titulo"]; ?></td>
                <td><a href="editar-produto.php?id=<?php echo $row["id"];?>">Editar<i class="material-icons orange-text">edit</i></a></td>
                <td><a href="#" onclick="confirmaExclusao(<?php echo $row["id"];?>)"><i class="material-icons red-text">delete</i></a></td>
            </tr>
       <?php  } ?>
            
         </table>   
        <?php          
            }else{
                echo "<p>Nenhum produto encontrado!</p>";
            }
           }
        ?>
        
            </div>
            
        </div>
        
    </body>
</html>
