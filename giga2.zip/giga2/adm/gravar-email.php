<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
            $email = $_POST["email"];
            $referencia = $_POST["referencia"];
            $id = $_POST["id_fornecedor"];
                        
                            
                include_once 'conexao.php';
                
                $sql = "insert into email values(null,
                '".$email."','".$referencia."','".$id."')";
                
              if(mysqli_query($con, $sql)){
                    $msg = "Gravado com sucesso!";
                   
                }else{
                    $msg = "Erro ao gravar!";
                }
                
                mysqli_close($con);
              
                      
        ?>
        
        <script>
            alert('<?php echo $msg;?>');
            //Redirecionar o usuário para o painel
            location.href="painel.php";
        </script>
        
    </body>
</html>