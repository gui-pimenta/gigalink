<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        
                $data = $_POST["data"];
                $nota = $_POST["nota"];
                $frete = $_POST["frete"];
                $desconto = $_POST["desconto"];
                $valortotal = $_POST["valortotal"];
                $id_produto = $_POST["id_produto"];
                $id_item = $_POST["id_item"];
        
        
            //Tratamento do salário 1.000,00 -> 1000.00
    
                $valortotal = str_replace(".", "", $valortotal);
                $valortotal = str_replace(",", ".", $valortotal);  
        
                $desconto = str_replace(".", "", $desconto);
                $desconto = str_replace(",", ".", $desconto); 
        
                $frete = str_replace(".", "", $frete);
                $frete = str_replace(",", ".", $frete); 
                            
                include_once 'conexao.php';

$sql = "insert into pedido values(null,
'".$data."','".$nota."','".$frete."','".$desconto."','".$valortotal."','".$id_produto."','".$id_item."')";
                
              if(mysqli_query($con, $sql)){
                    $msg = "Pedido realizado com sucesso!";
                   
                }else{
                    $msg = "Erro ao gravar!";
                }
                
                mysqli_close($con);              
                      
        ?>
  
        <script>
            alert('<?php echo $msg;?>');
            //Redirecionar o usuário para o painel
            location.href="painel.php";
        </script>
       
    </body>
</html>