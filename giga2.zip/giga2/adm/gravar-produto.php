<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
            $titulo = $_POST["titulo"];
            $dtevento = $_POST["dtevento"];
            $foto = $_FILES["foto"]; //array
            $descricao = $_POST["descricao"];
                                    
            //var_dump($foto);
            
            //Tratamento do arquivo
            //Extrair a extensão do arquivo
            
            //foto.ferias.jpg
            $ext = explode(".", $foto["name"]); //[foto][ferias][jpg]
            $ext = array_reverse($ext); //[jpg][ferias][foto]
            $ext = strtolower($ext[0]); //jpg
            
            //var_dump($ext);
            
            //Verificar se a extensão é inválida
            if($ext != "jpg" && $ext != "png" && $ext != "gif" && $ext != "jpeg"){
                echo "Arquivo inválido!";
            }elseif ($foto["size"] > 1024*500 ) {
                echo "Tamanho excedido!";
            }else{
                //echo "ok";
                $nomearquivo = date("YmdHis").rand(1000,9999).".".$ext;
                //echo $nomearquivo;
                
                include_once 'conexao.php';
                
                $sql = "insert into produto values(null,
                '".$titulo."','".$dtevento."','".$nomearquivo."','".$descricao."')";
                
              if(mysqli_query($con, $sql)){
                    $msg = "Gravado com sucesso!";
                   move_uploaded_file($foto["tmp_name"], "../img/".$nomearquivo);
                }else{
                    $msg = "Erro ao gravar!";
                }
                
                mysqli_close($con);
                                
            }
                
            
        ?>
        
        <script>
            alert('<?php echo $msg;?>');
            //Redirecionar o usuário para o painel
            location.href="../index.php";
        </script>
        
    </body>
</html>