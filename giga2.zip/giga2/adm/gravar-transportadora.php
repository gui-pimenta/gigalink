<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        
            $nome = $_POST["nome"];
            $id = $_POST["id_pedido"];
                        
                            
                include_once 'conexao.php';
                
                $sql = "insert into transportadora values(null,
                '".$nome."','".$id."')";
                
              if(mysqli_query($con, $sql)){
                    $msg = "Gravado com sucesso!";
                   
                }else{
                    $msg = "Erro ao gravar!";
                }
                
                mysqli_close($con);
              
                      
        ?>
  
        <script>
            alert('<?php echo $msg;?>');
            //Redirecionar o usuário para o painel
            location.href="painel.php";
        </script>
       
    </body>
</html>