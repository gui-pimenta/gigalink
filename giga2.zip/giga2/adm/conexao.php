<?php

    $con = mysqli_connect("localhost","root","","giga2");

?>
