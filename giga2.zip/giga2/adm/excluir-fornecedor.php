<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Excluir Fornecedor</title>
    </head>
    <body>
        <?php
        
           $id = $_GET["id"];
           
           $con = mysqli_connect("localhost","root","","giga2");
           
           $sql = "delete from fornecedor where id_fornecedor = ".$id;
           
           if(mysqli_query($con,$sql)){
               $msg = "Excluído com sucesso!";
           }else{
               $msg = "Erro ao excluir!";
           }
        
           mysqli_close($con);
                                
        ?>
     
        <script>
        
            alert('<?php echo $msg; ?>');
            location.href="painel.php";
        
        </script>
        
      
        
    </body>
</html>
