<?php 
    include_once 'conexao.php';
?>

<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Editar produto</title>
        <link rel="stylesheet" href="../materialize/css/materialize.min.css">
        
        <style>
            
        body{
            background-color:#d1d1d1;
                }
        .container{
            height: 100vh;
            display: flex;
                    }
        .login{
             width: 100vw;
             background-color:#eee;
             margin: auto;
             border-radius: 10px;
             padding: 20px;
                    } 
        h3{ 
            margin: auto;
            font-family: sans-serif;
            color: #00695c;
            text-align: center;
         }
         
     </style>    
        
    </head>
    <body>
        
        <?php
        
        $id = $_GET["id"];
        
        $con = mysqli_connect("localhost","root","","giga2");
        
        $sql = "select * from produto where id = ".$id;
        
        $result = mysqli_query($con,$sql);
        
        $row = mysqli_fetch_array($result);
        
        ?>
     
    
    <div class="container">
    
        <div class="login">
        
        <h3>Alteração de produto</h3>
        
        <form action="atualizar-produto.php" method="post">
            
            <input type="hidden" name="id" readonly value="<?php echo $row["id"]; ?>">
            
            <div class="input-field">
                <input type="text" name="titulo" id="titulo" required value="<?php echo $row["titulo"];?>">
                <label for="titulo"></label>
            </div> 
            
            <div class="input-field">
                <input type="text" name="descricao" id="descricao" required value="<?php echo $row["descricao"];?>">
                <label for="descricao"></label>
            </div>  
            
            <input type="submit" value="Atualizar" class="btn">
            
            <a href="../index.php" class="btn">Sair</a>
            
        </form>
        
        </div>
            
    </div>

    <script src="../materialize/js/materialize.min.js"></script>
  </body> 
</html>
