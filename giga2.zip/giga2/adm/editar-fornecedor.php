<?php 
    include_once 'conexao.php';
?>

<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Editar fornecedor</title>
        <link rel="stylesheet" href="../materialize/css/materialize.min.css">
        
        <style>
            
        body{
            background-color:#d1d1d1;
                }
        .container{
            height: 100vh;
            display: flex;
                    }
        .login{
             width: 800px;
             background-color:#eee;
             margin: auto;
             border-radius: 10px;
             padding: 20px;
                    } 
        h3{ 
            margin: auto;
            font-family: sans-serif;
            color: #00695c;
            text-align: center;
         }
         
     </style>    
        
    </head>
    <body>
        
        <?php
        
        $id = $_GET["id"];
        
        $con = mysqli_connect("localhost","root","","giga2");
        
        $sql = "select * from fornecedor where id_fornecedor = ".$id;
        
        $result = mysqli_query($con,$sql);
        
        $row = mysqli_fetch_array($result);
        
        ?>
     
    
    <div class="container">
    
        <div class="login">
        
        <h3>Alteração de fornecedor</h3>
        
        <form action="atualizar-fornecedor.php" method="post">
            
            <input type="hidden" name="id" readonly value="<?php echo $row["id_fornecedor"]; ?>">
            
            <div class="input-field">
                <input type="text" name="nome" id="nome" required value="<?php echo $row["nome"];?>">
                <label for="nome"></label>
            </div> 
            
            <div class="input-field">
                <input type="text" name="descricao" id="descricao" required value="<?php echo $row["descricao"];?>">
                <label for="descricao"></label>
            </div>  
            
            <input type="submit" value="Atualizar" class="btn">
            
        </form>
        
        </div>
            
    </div>

    <script src="../materialize/js/materialize.min.js"></script>
  </body> 
</html>
