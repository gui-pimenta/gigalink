<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
        <link rel="stylesheet" href="../materialize/css/materialize.min.css">

        
    </head>
    <body>

        <div class="container">

            <h3>Cadastrar item</h3>
            <!--
             enctype="multipart/form-data" -> Habilita o envio de arquivo pelo form
            -->
            <form action="gravar-item.php" method="post" enctype="multipart/form-data">

                <input type="number" name="valor" required placeholder="Informe o valor. Ex.: 1.000,00">
                <input type="number" name="quantidade" required placeholder="Digite a quantidade">
                <input type="number" name="id_produto" required placeholder="Digite o código do produto">
                <br><br>

                <input type="submit" value="Cadastrar" class="btn">

            </form>
            
            <br><br>

            <a href="../index.php" class="btn red lighten-2">Sair</a>
       
        </div>
        
        
    </body>
</html>

