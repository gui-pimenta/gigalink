<?php 
    include_once 'conexao.php';
?>

<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Consultar Fornecedor</title>
        <link rel="stylesheet" href="../materialize/css/materialize.css">
        <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
        <link rel="stylesheet" href="style.css">
        
                
        <script>
            function confirmaExclusao(id){
               if(confirm('Deseja realmente excluir esse produto?')){
                   location.href="excluir-fornecedor.php?id="+id;
               }                 
            }        
        </script>
        
    </head>
    <body>
      
      
        <div class="container">
            
            <div class="login">
            
            <h3>Consulta Fornecedor</h3>
            
            <form action="consultar-fornecedor.php" method="get">
                
                <input type="text" name="nome" placeholder="Digite o nome para pesquisar">
                <input type="submit" value="Pesquisar" class="btn">
                
                <a href="../index.php" class="btn">Sair</a>
                
            </form>
            <br>
                       
        <?php
        
            if(isset($_GET["nome"])){
                
                $nome = $_GET["nome"];
                
                $con = mysqli_connect("localhost","root","","giga2") or die('Erro de Conexão');
                
                $sql = "select * from fornecedor where nome like'".$nome."%'";
                
                $result = mysqli_query($con, $sql);
                
                if(mysqli_num_rows($result)>0){
        ?>     
        
        <table>
            
            <tr>
                <th>Nome</th>
            </tr>
        
        
        <?php
                while($row = mysqli_fetch_array($result)){
        ?>
            <tr>
                <td><?php echo $row["nome"]; ?></td>
                <td><a href="editar-fornecedor.php?id=<?php echo $row["id_fornecedor"];?>">Editar<i class="material-icons orange-text">edit</i></a></td>
                <td><a href="#" onclick="confirmaExclusao(<?php echo $row["id_fornecedor"];?>)"><i class="material-icons red-text">delete</i></a></td>
            </tr>
       <?php  } ?>
            
         </table>   
        <?php          
            }else{
                echo "<p>Nenhum fornecedor foi encontrado!</p>";
            }
           }
        ?>
        
            </div>
            
        </div>
        
    </body>
</html>
