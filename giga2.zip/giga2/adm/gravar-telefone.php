<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        
            $ddd = $_POST["ddd"];
            $telefone = $_POST["telefone"];
            $id = $_POST["id_fornecedor"];
                        
                            
                include_once 'conexao.php';
                
                $sql = "insert into telefone values(null,
                '".$ddd."','".$telefone."','".$id."')";
                
              if(mysqli_query($con, $sql)){
                    $msg = "Gravado com sucesso!";
                   
                }else{
                    $msg = "Erro ao gravar!";
                }
                
                mysqli_close($con);
              
                      
        ?>
        
        <script>
            alert('<?php echo $msg;?>');
            //Redirecionar o usuário para o painel
            location.href="painel.php";
        </script>
        
    </body>
</html>