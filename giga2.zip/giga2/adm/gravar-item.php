<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        
            
            $quantidade = $_POST["quantidade"];
            $valor = $_POST["valor"];
            $id = $_POST["id_produto"];
        
            //Tratamento do salário 1.000,00 -> 1000.00
    
                $valor = str_replace(".", "", $valor);
                $valor = str_replace(",", ".", $valor);  
                            
                include_once 'conexao.php';
                
                $sql = "insert into item values(null,'".$quantidade."','".$valor."','".$id."')";
                
              if(mysqli_query($con, $sql)){
                    $msg = "Gravado com sucesso!";
                   
                }else{
                    $msg = "Erro ao gravar!";
                }
                
                mysqli_close($con);
              
                      
        ?>
  
        <script>
            alert('<?php echo $msg;?>');
            //Redirecionar o usuário para o painel
            location.href="painel.php";
        </script>
       
    </body>
</html>