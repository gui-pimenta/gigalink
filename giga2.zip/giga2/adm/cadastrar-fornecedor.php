<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <title></title>
    <link rel="stylesheet" href="../materialize/css/materialize.min.css">
    <link rel="stylesheet" href="style.css">

    <script src="tinymce/tinymce.min.js"></script>
    <script>
        tinymce.init({
            selector: 'textarea',
            height: 150,
            menubar: false,
            plugins: [
                'advlist autolink lists link image charmap print preview anchor textcolor',
                'searchreplace visualblocks code fullscreen',
                'insertdatetime media table contextmenu paste code help wordcount'
            ],
            toolbar: 'undo redo |  formatselect | bold italic backcolor  | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | removeformat | help',
            content_css: [
                '//fonts.googleapis.com/css?family=Lato:300,300i,400,400i',
                '//www.tinymce.com/css/codepen.min.css'
            ]
        });
    </script>
    
</head>

<body>

    <div class="container">

        <div class="login">

            <h3>Cadastro do Fornecedor</h3>
            <!--
             enctype="multipart/form-data" -> Habilita o envio de arquivo pelo form
            -->
            <form action="gravar-fornecedor.php" method="post" enctype="multipart/form-data">

                <input type="text" name="nome" required placeholder="Nome do Fornecedor">
                <input type="text" name="descricao" required placeholder="Descricao">
                <input type="text" name="cidade" required placeholder="Cidade">
                <input type="text" name="endereco" required placeholder="Endereço">
                <input type="text" name="bairro" required placeholder="Bairro">
                <input type="text" name="numero" maxlength="10" required placeholder="Número">
                <input type="number" name="id_produto" maxlength="3" required placeholder="Código do Produto">
                
                <br>
                <input type="submit" value="Cadastrar" class="btn">

            </form>

            <br>

            <a href="painel.php" class="btn red lighten-2">Sair</a>

        </div>

    </div>


    
</body>

</html>

