<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        
            $nome = $_POST["nome"];
            $descricao = $_POST["descricao"];
            $cidade = $_POST["cidade"]; 
            $endereco = $_POST["endereco"];
            $bairro = $_POST["bairro"];
            $numero = $_POST["numero"];
            $produto = $_POST["id_produto"];
                                    
                            
            include_once 'conexao.php';

            $sql = "insert into fornecedor values(null,
            '".$nome."','".$descricao."','".$cidade."','".$endereco."','".$bairro."','".$numero."','".$produto."')";
                    
                     
             if(mysqli_query($con, $sql)){
                    $msg = "Gravado com sucesso!";

                }else{
                    $msg = "Erro ao gravar!";
                }
             
                     

            mysqli_close($con);

                    
        ?>
      
        <script>
            alert('<?php echo $msg;?>');
            //Redirecionar o usuário para o painel
            location.href="painel.php";
        </script>
      
    </body>
</html>