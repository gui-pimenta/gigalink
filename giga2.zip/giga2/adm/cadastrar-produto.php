<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
        <link rel="stylesheet" href="../materialize/css/materialize.min.css">

        <script src="tinymce/tinymce.min.js"></script>
        <script>tinymce.init({
                selector: 'textarea',
                height: 150,
                menubar: false,
                plugins: [
                    'advlist autolink lists link image charmap print preview anchor textcolor',
                    'searchreplace visualblocks code fullscreen',
                    'insertdatetime media table contextmenu paste code help wordcount'
                ],
                toolbar: 'undo redo |  formatselect | bold italic backcolor  | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | removeformat | help',
                content_css: [
                    '//fonts.googleapis.com/css?family=Lato:300,300i,400,400i',
                    '//www.tinymce.com/css/codepen.min.css']
            });
        </script>

    </head>
    <body>

        <div class="container">

            <h3>Cadastro do Produto</h3>
            <!--
             enctype="multipart/form-data" -> Habilita o envio de arquivo pelo form
            -->
            <form action="gravar-produto.php" method="post" enctype="multipart/form-data">

                <input type="text" name="titulo" required placeholder="Título do Produto">
                <input type="date" name="dtevento" required>
                <input type="file" name="foto" required>
                <br><br>
                <textarea name="descricao"></textarea>
                <br><br>

                <input type="submit" value="Cadastrar" class="btn">

            </form>
            
            <br><br>

            <a href="../index.php" class="btn red lighten-2">Sair</a>
       
        </div>
        
         

        <?php
        // put your code here
        ?>
    </body>
</html>

