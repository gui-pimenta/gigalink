<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
        <link rel="stylesheet" href="../materialize/css/materialize.min.css">

        <script src="tinymce/tinymce.min.js"></script>
        <script>tinymce.init({
                selector: 'textarea',
                height: 150,
                menubar: false,
                plugins: [
                    'advlist autolink lists link image charmap print preview anchor textcolor',
                    'searchreplace visualblocks code fullscreen',
                    'insertdatetime media table contextmenu paste code help wordcount'
                ],
                toolbar: 'undo redo |  formatselect | bold italic backcolor  | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | removeformat | help',
                content_css: [
                    '//fonts.googleapis.com/css?family=Lato:300,300i,400,400i',
                    '//www.tinymce.com/css/codepen.min.css']
            });
        </script>

    </head>
    <body>

        <div class="container">

            <h3>Cadastrar o telefone do fornecedor</h3>
            <!--
             enctype="multipart/form-data" -> Habilita o envio de arquivo pelo form
            -->
            <form action="gravar-telefone.php" method="post" enctype="multipart/form-data">

                <input type="text" name="ddd" maxlength="3" required placeholder="(DDD)">
                <input type="text" name="telefone" maxlength="8" required placeholder="Digite o número do telefone">
                <input type="number" name="id_fornecedor" required placeholder="Informe o código do fornecedor">
                <br><br>

                <input type="submit" value="Cadastrar" class="btn">

            </form>
            
            <br><br>

            <a href="../index.php" class="btn red lighten-2">Sair</a>
       
        </div>
        
        
    </body>
</html>

