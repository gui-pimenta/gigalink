CREATE DATABASE giga2;

USE giga2;

CREATE TABLE pedido(
id_pedido int primary key not null auto_increment,
datahora datetime not null,
notafiscal int not null,
valorfrete float not null default '0',
desconto float not null default '0',
valortotal float not null default '0',
id_produto int,
id_item int,
foreign key (id_produto) references produto(id_produto),
foreign key (id_item) references id_item(id_item)
);

CREATE TABLE item(
id_item int primary key unsigned not null auto_increment,
quantidade int not null default '0',
valor int not null default '0',
id_produto int (11),
foreign key (id_produto) references produto(id_produto)
);

CREATE TABLE produto(
id int auto_increment,
titulo varchar(50),
dtevento date,
foto varchar(50),
descricao text,
primary key (id),
foreign key (id) references pedido(id_pedido)    
);

CREATE TABLE transportadora(
id_transp int unsigned not null auto_increment,
nome varchar(45),
id_pedido int (100),
primary key (id_transp),
foreign key (id_pedido) references pedido(id_pedido)
);

CREATE TABLE fornecedor(
id_fornecedor int unsigned not null auto_increment,
nome varchar(45) not null,
descricao varchar (100) not null,
cidade varchar (40) not null,
endereco varchar (80) not null,
bairro varchar (40) not null,
numero int (10),
id_produto int (100),
primary key (id),
foreign key (id_produto) references produto(id_produto)
);

CREATE TABLE telefone(
id int unsigned not null auto_increment,
ddd char(3),
numero varchar (10),
id_fornecedor int (11),
primary key (id),
foreign key (id_fornecedor) references fornecedor(id_fornecedor)
);

CREATE TABLE email(
id int unsigned not null auto_increment,
email varchar(45) DEFAULT NULL,
referencia varchar(100) DEFAULT NULL,
id_fornecedor int(11) DEFAULT NULL,
primary key (id),
foreign key (id_fornecedor) references fornecedor(id_fornecedor)
);

